import random
import sys

def check() :
 ok=False    
 DNA = input("Please insert bacterium's DNA: ")   
 while ok==False :
  for x in DNA :
    if x is not "A" and x is not "C" and x is not "G" and x is not "T" :
     DNA=input("Wrong DNA sequence.Please insert correct DNA: ")
     return DNA
    else :
     ok=True
 return DNA
    
cont=True
inf=sys.maxsize
while cont==True :
    new_DNA=" "
    DNA=check()
    for x in DNA :
     part_of_DNA=x
     if part_of_DNA is "A" :
        rnA=random.randint(1,5) 
        part_of_DNA+="*" + str(rnA)+"A"
     elif part_of_DNA is "C" :
        rnC=random.randint(1,10)
        part_of_DNA+="*" + str(rnC)+"C"
     elif part_of_DNA is "G" :
        rnG=random.randint(1,inf)
        part_of_DNA+="*" + str(rnG)+"G"
     elif part_of_DNA is "T" :
        rnT=random.randint(1,inf)
        part_of_DNA+="*" + str(rnT)+"T"   
     new_DNA+=part_of_DNA     
    print("The infected version of: "+ DNA + " is " + new_DNA)     
    answer=input("Do you want to enter a new bacterium's DNA: ")
    if answer is "N" or answer is "n" or answer=="No" or answer=="no" or answer=="NO":
     cont=False
    elif answer is "Y" or answer is "y" or answer=="Yes" or answer=="yes" or answer=="YES":
     cont=True