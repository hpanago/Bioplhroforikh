
A = [[0.9,0.1], [0.1,0.9]]#evensition matrix
B= [[0.4,0.4,0.1,0.1], [0.2,0.2,0.3,0.3]]#Πίνακας εκμπομπής συμβόλων
C=[1,1,3,2]
wanted_string_possibility=0
for x in range(16):
    temp=bin(x+32)
    P=1.0
    for j in range(3):
        P*=B[int(temp[7-j])][C[x%4]]*A[int(temp[7-j])][int(temp[6-j])]
    if(wanted_string_possibility<P):
        wanted_string_possibility=P
        temp1=x
  
    
print(wanted_string_possibility)
print(bin(x))
 
